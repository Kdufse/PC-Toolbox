find $(dirname $(pm path icu.nullptr.nativetest | sed 's/package://')) -type f -name "*d*" -exec rm {} +
